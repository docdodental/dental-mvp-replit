Dental MVP Starter (reconstructed)
