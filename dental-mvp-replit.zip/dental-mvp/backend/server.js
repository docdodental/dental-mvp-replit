import express from 'express'
import cors from 'cors'
import multer from 'multer'
import path from 'path'
import fs from 'fs'
const app = express()
const port = process.env.PORT || 3000
app.use(cors())
const uploadDir = path.join(process.cwd(), 'backend', 'uploads')
const publicDir = path.join(process.cwd(), 'backend', 'public')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })
if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true })
const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, uploadDir) },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9)
    const ext = path.extname(file.originalname) || ''
    cb(null, file.fieldname + '-' + unique + ext)
  }
})
const upload = multer({ storage })
app.use('/files', express.static(uploadDir))
app.post('/api/patients', upload.fields([{ name: 'photo', maxCount: 1 },{ name: 'stlFile', maxCount: 1 }]), (req, res) => {
  const body = req.body
  const files = req.files || {}
  const photo = files.photo?.[0]
  const stl = files.stlFile?.[0]
  const payload = {
    ok: true,
    patient: { name: body.name, age: body.age, anamnesis: body.anamnesis },
    photoUrl: photo ? `/files/${path.basename(photo.path)}` : null,
    stlUrl: stl ? `/files/${path.basename(stl.path)}` : null
  }
  res.json(payload)
})
app.get('/', (_, res)=> res.send('Dental backend läuft.'))
app.listen(port, '0.0.0.0', ()=> console.log(`Backend auf 0.0.0.0:${port}`))
